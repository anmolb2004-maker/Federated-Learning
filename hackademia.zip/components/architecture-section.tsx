export default function ArchitectureSection() {
  const layers = [
    {
      title: "User Interface",
      subtitle: "Interactive Learning Layer",
      description: "Learners & Admins",
      icon: "👥",
    },
    {
      title: "AI Tutor & Sandbox",
      subtitle: "AI Intelligence & Practice Zone",
      description: "Smart Learning Environment",
      icon: "🤖",
    },
    {
      title: "Federated Learning",
      subtitle: "Privacy-Preserving Federated Core",
      description: "Secure Data Processing",
      icon: "🔐",
    },
    {
      title: "Database & Engine",
      subtitle: "Secure Storage & Analytics",
      description: "Contest & Analytics Engine",
      icon: "💾",
    },
  ]

  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Hackademia <span className="text-glow">Architecture</span>
          </h2>
          <p className="text-lg text-foreground/70">Built on cutting-edge technology for security and privacy</p>
        </div>

        <div className="relative">
          {/* Vertical Line */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-primary via-secondary to-primary transform -translate-x-1/2" />

          {/* Layers */}
          <div className="space-y-8">
            {layers.map((layer, index) => (
              <div key={index} className={`flex items-center gap-8 ${index % 2 === 1 ? "lg:flex-row-reverse" : ""}`}>
                {/* Content */}
                <div className="flex-1">
                  <div className="glassmorphism neon-border p-8 rounded-xl hover-glow">
                    <div className="text-4xl mb-3">{layer.icon}</div>
                    <h3 className="text-2xl font-bold text-primary mb-2">{layer.title}</h3>
                    <p className="text-foreground/70 mb-2">{layer.subtitle}</p>
                    <p className="text-sm text-foreground/60">{layer.description}</p>
                  </div>
                </div>

                {/* Dot on Timeline */}
                <div className="hidden lg:flex flex-col items-center">
                  <div className="w-6 h-6 bg-primary rounded-full border-4 border-background shadow-lg shadow-primary/50" />
                </div>

                {/* Spacer */}
                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
