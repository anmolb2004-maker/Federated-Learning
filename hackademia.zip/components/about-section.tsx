export default function AboutSection() {
  const features = [
    {
      icon: "🧠",
      title: "AI Tutor Guidance",
      description: "Chat, learn, and explore hacking tools interactively.",
    },
    {
      icon: "🧱",
      title: "Sandbox Labs",
      description: "Practice vulnerabilities safely, without harming real systems.",
    },
    {
      icon: "🔐",
      title: "Federated Learning",
      description: "Your data trains the AI — but never leaves your device.",
    },
  ]

  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Built for the <span className="text-glow">Next Generation</span> of Cyber Defenders.
          </h2>
          <p className="text-lg text-foreground/70 max-w-3xl mx-auto">
            Hackademia combines AI tutoring, privacy-first federated learning, and sandboxed ethical hacking labs to
            create a safe, smart, and engaging cybersecurity learning experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="glassmorphism neon-border p-8 rounded-xl hover-glow group">
              <div className="text-5xl mb-4 group-hover:scale-110 transition-transform">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-primary">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
