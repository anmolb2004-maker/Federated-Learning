"use client"

import { useEffect, useState } from "react"

export default function HeroSection() {
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number }>>([])

  useEffect(() => {
    // Generate floating particles
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
    }))
    setParticles(newParticles)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              linear-gradient(0deg, transparent 24%, rgba(0, 255, 255, 0.1) 25%, rgba(0, 255, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, 0.1) 75%, rgba(0, 255, 255, 0.1) 76%, transparent 77%, transparent),
              linear-gradient(90deg, transparent 24%, rgba(0, 255, 255, 0.1) 25%, rgba(0, 255, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(0, 255, 255, 0.1) 75%, rgba(0, 255, 255, 0.1) 76%, transparent 77%, transparent)
            `,
            backgroundSize: "50px 50px",
            animation: "cyber-grid 20s linear infinite",
          }}
        />
      </div>

      {/* Floating Particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute w-1 h-1 bg-primary rounded-full opacity-50"
          style={{
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            animation: `float ${4 + particle.id * 0.2}s ease-in-out infinite`,
          }}
        />
      ))}

      {/* Gradient Orbs */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl opacity-20 animate-pulse" />
      <div className="absolute bottom-20 left-10 w-72 h-72 bg-secondary/20 rounded-full blur-3xl opacity-20 animate-pulse" />

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-8 inline-block">
          <span className="text-primary text-sm font-semibold tracking-widest uppercase">Welcome to the Future</span>
        </div>

        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          <span className="text-glow">Learn.</span>
          <span className="text-white mx-3">Hack.</span>
          <span className="text-glow-violet">Evolve</span>
          <br />
          <span className="text-white">— The Future of Cybersecurity Starts Here.</span>
        </h1>

        <p className="text-lg sm:text-xl text-foreground/80 mb-12 max-w-3xl mx-auto leading-relaxed">
          Hackademia is an AI-powered ethical hacking academy where you can learn cybersecurity hands-on, safely and
          privately.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button className="px-8 py-4 rounded-full bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-bold text-lg hover:shadow-2xl hover:shadow-primary/50 transition-all transform hover:scale-105 glow-pulse">
            Start Learning
          </button>
          <button className="px-8 py-4 rounded-full border-2 border-secondary text-secondary font-bold text-lg hover:bg-secondary/10 transition-all hover-glow">
            Join a Contest
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 sm:gap-8 max-w-2xl mx-auto">
          <div className="glassmorphism neon-border p-4 rounded-lg">
            <div className="text-2xl sm:text-3xl font-bold text-primary">10K+</div>
            <div className="text-sm text-foreground/60">Active Learners</div>
          </div>
          <div className="glassmorphism neon-border p-4 rounded-lg">
            <div className="text-2xl sm:text-3xl font-bold text-primary">500+</div>
            <div className="text-sm text-foreground/60">Labs & Challenges</div>
          </div>
          <div className="glassmorphism neon-border p-4 rounded-lg">
            <div className="text-2xl sm:text-3xl font-bold text-primary">₹50L+</div>
            <div className="text-sm text-foreground/60">Prize Pool</div>
          </div>
        </div>
      </div>
    </section>
  )
}
