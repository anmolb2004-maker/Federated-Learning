export default function TestimonialsSection() {
  const testimonials = [
    {
      name: "Alex Chen",
      role: "Student",
      avatar: "👨‍🎓",
      quote: "Hackademia made ethical hacking fun and safe to learn. The AI tutor is incredibly helpful!",
    },
    {
      name: "Dr. Sarah Williams",
      role: "Educator",
      avatar: "👩‍🏫",
      quote: "The AI tutor feels like a real instructor — brilliant platform for teaching cybersecurity!",
    },
    {
      name: "Marcus Johnson",
      role: "Security Professional",
      avatar: "👨‍💼",
      quote: "Finally, a cyber learning site that respects privacy. Federated learning is the future!",
    },
  ]

  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Trusted by Learners <span className="text-glow">Worldwide</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="glassmorphism neon-border p-8 rounded-xl hover-glow">
              <div className="flex items-center gap-4 mb-6">
                <div className="text-5xl">{testimonial.avatar}</div>
                <div>
                  <h3 className="font-bold text-foreground">{testimonial.name}</h3>
                  <p className="text-sm text-primary">{testimonial.role}</p>
                </div>
              </div>
              <p className="text-foreground/80 italic">"{testimonial.quote}"</p>
              <div className="mt-4 flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <span key={i} className="text-lg">
                    ⭐
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
