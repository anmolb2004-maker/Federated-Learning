export default function CommunitySection() {
  const socialLinks = [
    { name: "Discord", icon: "💬", url: "#" },
    { name: "LinkedIn", icon: "💼", url: "#" },
    { name: "GitHub", icon: "🐙", url: "#" },
  ]

  return (
    <section id="community" className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-4xl sm:text-5xl font-bold mb-6">
          Join the <span className="text-glow">Hackademia</span> Network
        </h2>
        <p className="text-lg text-foreground/70 mb-12">
          Connect with cybersecurity learners, experts, and educators from around the world. Collaborate, compete, and
          grow together in the Hackademia community.
        </p>

        {/* Social Links */}
        <div className="flex flex-wrap justify-center gap-6 mb-12">
          {socialLinks.map((link, index) => (
            <a
              key={index}
              href={link.url}
              className="glassmorphism neon-border p-6 rounded-xl hover-glow inline-flex flex-col items-center gap-3 group"
            >
              <div className="text-5xl group-hover:scale-110 transition-transform">{link.icon}</div>
              <span className="text-primary font-semibold">{link.name}</span>
            </a>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="glassmorphism neon-border p-8 rounded-xl max-w-md mx-auto">
          <h3 className="text-xl font-bold text-primary mb-4">Stay Updated</h3>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 rounded-lg bg-background border border-primary/30 text-foreground placeholder-foreground/50 focus:outline-none focus:border-primary"
            />
            <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold hover:shadow-lg hover:shadow-primary/50 transition-all">
              Subscribe
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}
