export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="relative border-t border-primary/10 bg-background/50 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center text-foreground font-bold text-sm">
                H
              </div>
              <span className="text-lg font-bold text-glow">Hackademia</span>
            </div>
            <p className="text-foreground/60 text-sm">The future of cybersecurity education.</p>
          </div>

          {/* Links */}
          {[
            { title: "Product", links: ["Features", "Pricing", "Security"] },
            { title: "Company", links: ["About", "Blog", "Careers"] },
            { title: "Resources", links: ["Docs", "API", "Support"] },
          ].map((column, index) => (
            <div key={index}>
              <h3 className="font-bold text-foreground mb-4">{column.title}</h3>
              <ul className="space-y-2">
                {column.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a href="#" className="text-foreground/60 hover:text-primary transition-colors text-sm">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="border-t border-primary/10 pt-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-foreground/60 text-sm">© {currentYear} Hackademia. All Rights Reserved.</p>
            <p className="text-primary text-sm font-semibold">Learn. Hack. Evolve — The Future of Cybersecurity.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
