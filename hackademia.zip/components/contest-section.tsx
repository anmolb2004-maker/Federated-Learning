"use client"

import { useState, useEffect } from "react"

export default function ContestSection() {
  const [timeLeft, setTimeLeft] = useState({ days: 5, hours: 12, minutes: 34, seconds: 56 })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        let { days, hours, minutes, seconds } = prev
        seconds--
        if (seconds < 0) {
          seconds = 59
          minutes--
          if (minutes < 0) {
            minutes = 59
            hours--
            if (hours < 0) {
              hours = 23
              days--
            }
          }
        }
        return { days, hours, minutes, seconds }
      })
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <section id="contests" className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-4xl sm:text-5xl font-bold mb-6">
              Turn Your Skills Into <span className="text-glow">Victories</span>
            </h2>
            <p className="text-lg text-foreground/70 mb-8">
              Participate in exciting cybersecurity contests where learners identify vulnerabilities in safe, simulated
              environments. Compete against others, climb leaderboards, and earn rewards — all while improving your
              skills.
            </p>
            <p className="text-lg text-foreground/70 mb-8">
              Join contests starting at <span className="text-primary font-bold">₹50</span> and showcase your
              cybersecurity expertise in a safe arena.
            </p>
            <button className="px-8 py-4 rounded-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-bold text-lg hover:shadow-2xl hover:shadow-primary/50 transition-all transform hover:scale-105">
              Enter Contest Arena
            </button>
          </div>

          {/* Right - Leaderboard & Timer */}
          <div className="space-y-6">
            {/* Timer */}
            <div className="glassmorphism neon-border p-8 rounded-xl">
              <h3 className="text-xl font-bold text-primary mb-6">Next Contest Starts In</h3>
              <div className="grid grid-cols-4 gap-4">
                {[
                  { label: "Days", value: timeLeft.days },
                  { label: "Hours", value: timeLeft.hours },
                  { label: "Minutes", value: timeLeft.minutes },
                  { label: "Seconds", value: timeLeft.seconds },
                ].map((item, index) => (
                  <div key={index} className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">{String(item.value).padStart(2, "0")}</div>
                    <div className="text-xs text-foreground/60 uppercase">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Leaderboard Preview */}
            <div className="glassmorphism neon-border p-8 rounded-xl">
              <h3 className="text-xl font-bold text-primary mb-6">Top Performers</h3>
              <div className="space-y-3">
                {[
                  { rank: 1, name: "CyberNinja", score: 9850, medal: "🥇" },
                  { rank: 2, name: "HackMaster", score: 9720, medal: "🥈" },
                  { rank: 3, name: "SecureCode", score: 9650, medal: "🥉" },
                ].map((entry) => (
                  <div
                    key={entry.rank}
                    className="flex items-center justify-between p-3 bg-primary/5 rounded-lg border border-primary/20"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{entry.medal}</span>
                      <div>
                        <div className="font-semibold text-foreground">{entry.name}</div>
                        <div className="text-xs text-foreground/60">Rank #{entry.rank}</div>
                      </div>
                    </div>
                    <div className="text-primary font-bold">{entry.score}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
