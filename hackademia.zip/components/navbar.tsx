"use client"

import { useState } from "react"
import Link from "next/link"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed top-0 w-full z-50 glassmorphism border-b border-primary/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center text-foreground font-bold text-sm group-hover:shadow-lg group-hover:shadow-primary/50 transition-all">
              H
            </div>
            <span className="text-xl font-bold text-glow hidden sm:inline">Hackademia</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-foreground/80 hover:text-primary transition-colors">
              Features
            </Link>
            <Link href="#contests" className="text-foreground/80 hover:text-primary transition-colors">
              Contests
            </Link>
            <Link href="#community" className="text-foreground/80 hover:text-primary transition-colors">
              Community
            </Link>
          </div>

          {/* CTA Buttons */}
          <div className="hidden md:flex items-center gap-4">
            <button className="px-6 py-2 rounded-full border border-primary/50 text-primary hover:bg-primary/10 transition-all hover-glow">
              Sign In
            </button>
            <button className="px-6 py-2 rounded-full bg-gradient-to-r from-primary to-secondary text-primary-foreground font-semibold hover:shadow-lg hover:shadow-primary/50 transition-all">
              Get Started
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-primary">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <Link href="#features" className="block px-4 py-2 text-foreground/80 hover:text-primary">
              Features
            </Link>
            <Link href="#contests" className="block px-4 py-2 text-foreground/80 hover:text-primary">
              Contests
            </Link>
            <Link href="#community" className="block px-4 py-2 text-foreground/80 hover:text-primary">
              Community
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
