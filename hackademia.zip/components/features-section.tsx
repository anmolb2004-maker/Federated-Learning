"use client"

import { useState } from "react"

export default function FeaturesSection() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  const features = [
    {
      title: "AI Chat Tutor",
      description: "Ask questions, explore topics, and learn cybersecurity with AI guidance.",
      icon: "💬",
      color: "from-primary to-primary/50",
    },
    {
      title: "Safe Dummy Labs",
      description: "Train on simulated networks and websites without risk.",
      icon: "🔬",
      color: "from-secondary to-secondary/50",
    },
    {
      title: "Privacy-Preserving AI",
      description: "Hackademia uses Federated Learning for total user privacy.",
      icon: "🛡️",
      color: "from-primary to-secondary",
    },
    {
      title: "Cyber Contests",
      description: "Test your skills in live challenges and win recognition.",
      icon: "🏆",
      color: "from-secondary to-primary",
    },
    {
      title: "Progress Tracker",
      description: "Monitor your learning journey and skill development.",
      icon: "📊",
      color: "from-primary to-primary/50",
    },
  ]

  return (
    <section id="features" className="relative py-20 px-4 sm:px-6 lg:px-8 border-t border-primary/10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Powerful Features for <span className="text-glow">Cyber Excellence</span>
          </h2>
          <p className="text-lg text-foreground/70">Everything you need to master cybersecurity</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              onMouseEnter={() => setHoveredCard(index)}
              onMouseLeave={() => setHoveredCard(null)}
              className={`glassmorphism neon-border p-8 rounded-xl hover-glow cursor-pointer transition-all ${
                hoveredCard === index ? "lg:scale-105" : ""
              }`}
            >
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h3 className="text-xl font-bold mb-3 text-primary">{feature.title}</h3>
              <p className="text-foreground/70">{feature.description}</p>
              <div className={`mt-4 h-1 w-12 bg-gradient-to-r ${feature.color} rounded-full`} />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
