"use client"

import { useState, useEffect } from "react"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import AboutSection from "@/components/about-section"
import FeaturesSection from "@/components/features-section"
import ContestSection from "@/components/contest-section"
import ArchitectureSection from "@/components/architecture-section"
import TestimonialsSection from "@/components/testimonials-section"
import CommunitySection from "@/components/community-section"
import Footer from "@/components/footer"

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <main className="min-h-screen bg-background overflow-hidden">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <FeaturesSection />
      <ContestSection />
      <ArchitectureSection />
      <TestimonialsSection />
      <CommunitySection />
      <Footer />
    </main>
  )
}
